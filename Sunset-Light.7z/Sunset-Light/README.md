# Sunset GTK Themes
Gtk2 themes base on : [Adwaita](https://gitlab.gnome.org/GNOME/gnome-themes-extra/-/tree/gnome-3-22/themes) </br>
Gtk3 themes base on : [Adwaita](https://gitlab.gnome.org/GNOME/gtk/-/tree/gtk-3-24/gtk/theme/Adwaita) </br>
Gnome shell themes base on : [Gnome Shell themes ](https://gitlab.gnome.org/GNOME/gnome-shell/-/tree/gnome-3-38/data/theme) </br>
Cinnamon themes base on : [Cinnamon themes](https://github.com/linuxmint/cinnamon/tree/master/data/theme) </br>
Xfwm4 themes base on : [Xfwm4 Default-theme](https://gitlab.xfce.org/Dridi/xfwm4/-/tree/master/themes/default)</br>
Metacity themes base on : [Metacity](https://gitlab.gnome.org/Archive/gnome-themes-extra/-/tree/a37321cb81e90445eefd903ce58fbdf0b7a16506/themes/Adwaita/metacity-1)</br>
License : [GPLv3](https://choosealicense.com/licenses/gpl-3.0/)</br></br>
SCREENSHOTS:</br>
![sunsetscreenshot](https://i.ibb.co/nLTK2vB/sunset-nautilus-screenshots.png "sunset-nautilus-screenshot")</br></br>
![sunsetscreenshot](https://i.ibb.co/D4YKRjX/sunset-widget-factory-screenshots.png "sunset-widget-factory-screenshot")</br></br>
